Galaxy Testing
==============

The Galaxy code base is large and contains many kinds of tests. Please
consult the [Galaxy
wiki](http://wiki.galaxyproject.org/Admin/Running%20Tests) for more
information on testing Galaxy.
