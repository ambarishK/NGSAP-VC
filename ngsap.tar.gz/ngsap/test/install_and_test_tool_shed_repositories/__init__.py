"""Install and test tool shed repositories."""
