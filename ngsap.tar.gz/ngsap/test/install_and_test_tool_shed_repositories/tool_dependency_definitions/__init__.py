"""Install and test tool shed repositories of type tool_dependency_definition."""
