"""Install and test tool shed repositories that contain tools and tool test components."""
