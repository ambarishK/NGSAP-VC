This directory contains the Galaxy framework written by Carl Eberhard
for running headless browser tests using CasperJS and PhantomJS.

See notes at the top of casperjs_runner.py for more information.
