""" Test filters used by test_toolbox_filters.py.
"""


def filter_tool( context, tool ):
    """Test Filter Tool"""
    return False


def filter_section( context, section ):
    """Test Filter Section"""
    return False


def filter_label_1( context, label ):
    """Test Filter Label 1"""
    return False


def filter_label_2( context, label ):
    """Test Filter Label 2"""
    return False
