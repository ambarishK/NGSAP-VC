

def tophat():
    # This should override definition in 10_site.py
    return 'instance_dest_id'

